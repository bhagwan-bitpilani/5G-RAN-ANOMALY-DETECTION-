import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time
import random

def generate_nr_cells_excel():
    """Generate dummy NR cells data for NR2600 and NR700 bands"""
    
    nr2600_cells = []
    nr700_cells = []
    
    # Generate NR2600 cells
    for i in range(1, 51):
        nr2600_cells.append({
            'cell_id': f'NR2600_{i:03d}',
            'band': 'NR2600',
            'location': f'Sector_{(i-1)//10 + 1}',
            'sector': ((i-1) % 3) + 1,
            'latitude': 40.7128 + (i * 0.001),
            'longitude': -74.0060 + (i * 0.001)
        })
    
    # Generate NR700 cells
    for i in range(1, 51):
        nr700_cells.append({
            'cell_id': f'NR700_{i:03d}',
            'band': 'NR700',
            'location': f'Sector_{(i-1)//10 + 1}',
            'sector': ((i-1) % 3) + 1,
            'latitude': 40.7128 - (i * 0.001),
            'longitude': -74.0060 - (i * 0.001)
        })
    
    all_cells = nr2600_cells + nr700_cells
    df = pd.DataFrame(all_cells)
    df.to_excel('nr_cells_demo.xlsx', index=False)
    print("Generated NR cells template with 100 cells (50 NR2600, 50 NR700)")

def simulate_kpi_data():
    """Simulate KPI data streaming"""
    base_url = "http://localhost:8000"
    
    # Login to get token
    try:
        login_response = requests.post(f"{base_url}/api/auth/login", data={
            "username": "admin",
            "password": "admin"
        })
        print("Login successful")
    except:
        print("Backend not available. Start the application first.")
        return
    
    # Simulate KPI data streaming
    print("Starting KPI data simulation...")
    
    bands = ['NR2600', 'NR700']
    
    for i in range(100):  # Send 100 data points
        try:
            kpi_data = {
                'cell_id': f'{random.choice(bands)}_{random.randint(1, 50):03d}',
                'kpi_type': 'throughput',
                'nr_ue_throughput': max(0, np.random.normal(100, 30)),
                'data_session_success_rate': max(0, min(100, np.random.normal(98, 2))),
                'endc_setup_success_rate': max(0, min(100, np.random.normal(97, 3))),
                'pscell_change_success_rate': max(0, min(100, np.random.normal(95, 4))),
                'latency': max(1, np.random.normal(10, 5)),
                'nr_connected_users': random.randint(10, 100),
                'downlink_latency': max(1, np.random.normal(15, 6))
            }
            
            response = requests.post(f"{base_url}/api/kpi/stream", json=kpi_data)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('anomaly_detected'):
                    print(f"🚨 Anomaly detected! Score: {result.get('anomaly_score'):.3f}")
                else:
                    print(f"✓ Data point {i+1} processed")
            else:
                print(f"✗ Failed to send data point {i+1}")
                
        except Exception as e:
            print(f"Error sending data: {e}")
        
        time.sleep(2)  # Wait 2 seconds between data points

if __name__ == "__main__":
    print("1. Generating NR cells Excel file...")
    generate_nr_cells_excel()
    
    print("\n2. Starting KPI data simulation...")
    print("   Make sure the backend is running on http://localhost:8000")
    input("   Press Enter to start simulation...")
    
    simulate_kpi_data()
