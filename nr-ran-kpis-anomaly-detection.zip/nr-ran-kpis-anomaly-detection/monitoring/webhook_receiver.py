from flask import Flask, request, jsonify
import json
from datetime import datetime

app = Flask(__name__)

@app.route('/', methods=['POST'])
@app.route('/critical', methods=['POST'])
@app.route('/warning', methods=['POST'])
def webhook():
    data = request.json
    print(f"\n=== ALERT RECEIVED at {datetime.now()} ===")
    print(json.dumps(data, indent=2))
    print("=== END ALERT ===\n")
    return jsonify({"status": "success"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
