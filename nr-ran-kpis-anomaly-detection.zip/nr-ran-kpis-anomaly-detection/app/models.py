# app/models.py
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class NRCell(Base):
    __tablename__ = "nr_cells"
    
    id = Column(Integer, primary_key=True, index=True)
    cell_id = Column(String(50), unique=True, index=True)
    band = Column(String(20))  # NR2600, NR700
    location = Column(String(100))
    sector = Column(Integer)
    status = Column(String(20), default="active")
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "cell_id": self.cell_id,
            "band": self.band,
            "location": self.location,
            "sector": self.sector,
            "status": self.status
        }

class KpiData(Base):
    __tablename__ = "kpi_data"
    
    id = Column(Integer, primary_key=True, index=True)
    cell_id = Column(String(50), index=True)
    kpi_type = Column(String(50))
    kpi_value = Column(Float)
    timestamp = Column(DateTime, default=datetime.utcnow)
    band = Column(String(20))
    
    # NR KPIs
    nr_ue_throughput = Column(Float)  # Mbps
    data_session_success_rate = Column(Float)  # %
    endc_setup_success_rate = Column(Float)  # %
    pscell_change_success_rate = Column(Float)  # %
    latency = Column(Float)  # ms
    nr_connected_users = Column(Integer)
    downlink_latency = Column(Float)  # ms
    
    def to_dict(self):
        return {
            "id": self.id,
            "cell_id": self.cell_id,
            "kpi_type": self.kpi_type,
            "kpi_value": self.kpi_value,
            "timestamp": self.timestamp.isoformat(),
            "band": self.band,
            "nr_ue_throughput": self.nr_ue_throughput,
            "data_session_success_rate": self.data_session_success_rate,
            "endc_setup_success_rate": self.endc_setup_success_rate,
            "pscell_change_success_rate": self.pscell_change_success_rate,
            "latency": self.latency,
            "nr_connected_users": self.nr_connected_users,
            "downlink_latency": self.downlink_latency
        }

class AnomalyDetection(Base):
    __tablename__ = "anomaly_detections"
    
    id = Column(Integer, primary_key=True, index=True)
    kpi_id = Column(Integer, index=True)
    anomaly_score = Column(Float)
    detected_at = Column(DateTime, default=datetime.utcnow)
    kpi_type = Column(String(50))
    is_resolved = Column(Boolean, default=False)
    resolution_notes = Column(Text)
    
    def to_dict(self):
        return {
            "id": self.id,
            "kpi_id": self.kpi_id,
            "anomaly_score": self.anomaly_score,
            "detected_at": self.detected_at.isoformat(),
            "kpi_type": self.kpi_type,
            "is_resolved": self.is_resolved
        }

class ResourceMetrics(Base):
    __tablename__ = "resource_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    deployment = Column(String(50))
    cpu_usage = Column(Float)
    memory_usage = Column(Float)
    replica_count = Column(Integer)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "deployment": self.deployment,
            "cpu_usage": self.cpu_usage,
            "memory_usage": self.memory_usage,
            "replica_count": self.replica_count,
            "timestamp": self.timestamp.isoformat()
        }
