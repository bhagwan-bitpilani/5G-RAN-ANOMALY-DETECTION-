import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.svm import OneClassSVM
import xgboost as xgb
import joblib
import asyncio
from typing import Dict, List
import logging

logger = logging.getLogger(__name__)

class AnomalyDetector:
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.features = [
            'nr_ue_throughput', 'data_session_success_rate', 
            'endc_setup_success_rate', 'pscell_change_success_rate',
            'latency', 'nr_connected_users', 'downlink_latency'
        ]
    
    async def initialize_models(self):
        """Initialize ML models for different KPI types"""
        kpi_models = {
            'throughput': IsolationForest(contamination=0.1, random_state=42),
            'success_rate': OneClassSVM(nu=0.1, kernel="rbf", gamma=0.1),
            'latency': xgb.XGBRegressor(),
            'user_count': IsolationForest(contamination=0.05, random_state=42)
        }
        
        for kpi_type, model in kpi_models.items():
            self.models[kpi_type] = model
            self.scalers[kpi_type] = StandardScaler()
        
        # Train with initial data if available
        await self.initial_training()
    
    async def initial_training(self):
        """Perform initial training with historical data"""
        # This would load historical data for initial training
        # For now, we'll create some dummy data
        try:
            dummy_data = self.generate_dummy_training_data()
            
            for kpi_type in self.models.keys():
                if kpi_type == 'latency':
                    # Regression model for latency
                    X = dummy_data[self.features]
                    y = dummy_data['latency']
                    self.models[kpi_type].fit(X, y)
                else:
                    # Anomaly detection models
                    X = dummy_data[self.features]
                    X_scaled = self.scalers[kpi_type].fit_transform(X)
                    self.models[kpi_type].fit(X_scaled)
                    
            logger.info("Initial model training completed")
        except Exception as e:
            logger.error(f"Initial training failed: {str(e)}")
    
    def generate_dummy_training_data(self, n_samples=1000):
        """Generate dummy training data for initial model setup"""
        np.random.seed(42)
        
        return pd.DataFrame({
            'nr_ue_throughput': np.random.normal(100, 20, n_samples),
            'data_session_success_rate': np.random.normal(98, 1, n_samples),
            'endc_setup_success_rate': np.random.normal(97, 2, n_samples),
            'pscell_change_success_rate': np.random.normal(95, 3, n_samples),
            'latency': np.random.normal(10, 2, n_samples),
            'nr_connected_users': np.random.poisson(50, n_samples),
            'downlink_latency': np.random.normal(15, 3, n_samples)
        })
    
    async def detect_anomalies(self, kpi_data: Dict) -> Dict:
        """Detect anomalies in incoming KPI data"""
        try:
            kpi_type = self._classify_kpi_type(kpi_data['kpi_type'])
            
            # Prepare features
            features = np.array([[
                kpi_data.get('nr_ue_throughput', 0),
                kpi_data.get('data_session_success_rate', 0),
                kpi_data.get('endc_setup_success_rate', 0),
                kpi_data.get('pscell_change_success_rate', 0),
                kpi_data.get('latency', 0),
                kpi_data.get('nr_connected_users', 0),
                kpi_data.get('downlink_latency', 0)
            ]])
            
            if kpi_type == 'latency':
                # Use regression-based anomaly detection
                prediction = self.models[kpi_type].predict(features)[0]
                actual = kpi_data.get('latency', 0)
                residual = abs(actual - prediction)
                is_anomaly = residual > 5  # threshold
                score = residual / 10  # normalized score
            else:
                # Use unsupervised anomaly detection
                features_scaled = self.scalers[kpi_type].transform(features)
                
                if hasattr(self.models[kpi_type], 'decision_function'):
                    score = -self.models[kpi_type].decision_function(features_scaled)[0]
                else:
                    score = -self.models[kpi_type].score_samples(features_scaled)[0]
                
                prediction = self.models[kpi_type].predict(features_scaled)[0]
                is_anomaly = prediction == -1
            
            return {
                'is_anomaly': bool(is_anomaly),
                'score': float(score),
                'kpi_type': kpi_type,
                'timestamp': kpi_data.get('timestamp')
            }
            
        except Exception as e:
            logger.error(f"Anomaly detection error: {str(e)}")
            return {'is_anomaly': False, 'score': 0.0, 'error': str(e)}
    
    def _classify_kpi_type(self, kpi_name: str) -> str:
        """Classify KPI type for model selection"""
        if 'throughput' in kpi_name.lower():
            return 'throughput'
        elif 'success' in kpi_name.lower() or 'rate' in kpi_name.lower():
            return 'success_rate'
        elif 'latency' in kpi_name.lower():
            return 'latency'
        elif 'user' in kpi_name.lower():
            return 'user_count'
        else:
            return 'throughput'  # default
    
    async def retrain_model(self, new_data: pd.DataFrame, kpi_type: str):
        """Retrain model with new data"""
        try:
            if kpi_type in self.models:
                if kpi_type == 'latency':
                    X = new_data[self.features]
                    y = new_data['latency']
                    self.models[kpi_type].fit(X, y)
                else:
                    X = new_data[self.features]
                    X_scaled = self.scalers[kpi_type].fit_transform(X)
                    self.models[kpi_type].fit(X_scaled)
                
                logger.info(f"Model {kpi_type} retrained successfully")
        except Exception as e:
            logger.error(f"Model retraining failed: {str(e)}")
