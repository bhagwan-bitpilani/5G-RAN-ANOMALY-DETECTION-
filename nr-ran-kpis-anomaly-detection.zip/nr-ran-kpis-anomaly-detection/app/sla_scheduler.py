import asyncio
import numpy as np
from kubernetes import client, config
from prometheus_api_client import PrometheusConnect
import logging
from typing import Dict, List
import pandas as pd
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class SLAScheduler:
    def __init__(self):
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()
        
        self.v1 = client.CoreV1Api()
        self.apps_v1 = client.AppsV1Api()
        self.prometheus = PrometheusConnect(url="http://prometheus:9090")
        
        self.sla_targets = {
            'response_time': 100,  # ms
            'throughput': 95,      # %
            'availability': 99.9,  # %
            'error_rate': 1        # %
        }
    
    async def optimize_resources(self):
        """Main optimization loop"""
        while True:
            try:
                # Get current metrics
                metrics = await self.get_cluster_metrics()
                
                # Get application performance
                app_performance = await self.get_application_performance()
                
                # AI-based decision making
                decisions = await self.make_scaling_decisions(metrics, app_performance)
                
                # Execute decisions
                await self.execute_decisions(decisions)
                
                # Sleep for 1 minute
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"Scheduler error: {str(e)}")
                await asyncio.sleep(30)
    
    async def get_cluster_metrics(self) -> Dict:
        """Get cluster resource metrics from Prometheus"""
        try:
            # CPU usage
            cpu_query = 'sum(rate(container_cpu_usage_seconds_total[5m])) by (pod)'
            cpu_result = self.prometheus.custom_query(cpu_query)
            
            # Memory usage
            memory_query = 'container_memory_usage_bytes{pod=~".*"}'
            memory_result = self.prometheus.custom_query(memory_query)
            
            # Node resources
            node_cpu_query = '100 - (avg by (instance) (rate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)'
            node_cpu_result = self.prometheus.custom_query(node_cpu_query)
            
            return {
                'cpu_usage': self._parse_prometheus_result(cpu_result),
                'memory_usage': self._parse_prometheus_result(memory_result),
                'node_cpu': self._parse_prometheus_result(node_cpu_result)
            }
        except Exception as e:
            logger.error(f"Metrics collection error: {str(e)}")
            return {}
    
    async def get_application_performance(self) -> Dict:
        """Get application performance metrics"""
        try:
            # KPI processing rate
            processing_rate_query = 'rate(kpi_processing_total[5m])'
            processing_rate = self.prometheus.custom_query(processing_rate_query)
            
            # Anomaly detection latency
            latency_query = 'histogram_quantile(0.95, rate(anomaly_detection_duration_seconds_bucket[5m]))'
            latency = self.prometheus.custom_query(latency_query)
            
            # Error rate
            error_rate_query = 'rate(kpi_processing_errors_total[5m])'
            error_rate = self.prometheus.custom_query(error_rate_query)
            
            return {
                'processing_rate': self._parse_prometheus_result(processing_rate),
                'detection_latency': self._parse_prometheus_result(latency),
                'error_rate': self._parse_prometheus_result(error_rate)
            }
        except Exception as e:
            logger.error(f"Performance metrics error: {str(e)}")
            return {}
    
    async def make_scaling_decisions(self, metrics: Dict, performance: Dict) -> List[Dict]:
        """AI-based decision making for resource scaling"""
        decisions = []
        
        # Analyze current state vs SLA
        current_latency = performance.get('detection_latency', {}).get('value', 0)
        target_latency = self.sla_targets['response_time'] / 1000  # Convert to seconds
        
        if current_latency > target_latency * 1.2:
            # Scale up backend API
            decisions.append({
                'action': 'scale_up',
                'deployment': 'backend-api',
                'reason': f'High latency: {current_latency:.3f}s > {target_latency:.3f}s'
            })
        elif current_latency < target_latency * 0.8:
            # Scale down if significantly below target
            decisions.append({
                'action': 'scale_down',
                'deployment': 'backend-api',
                'reason': f'Low latency: {current_latency:.3f}s < {target_latency:.3f}s'
            })
        
        # Check error rate
        error_rate = performance.get('error_rate', {}).get('value', 0)
        if error_rate > self.sla_targets['error_rate']:
            decisions.append({
                'action': 'scale_up',
                'deployment': 'ml-scheduler',
                'reason': f'High error rate: {error_rate:.1f}%'
            })
        
        return decisions
    
    async def execute_decisions(self, decisions: List[Dict]):
        """Execute scaling decisions"""
        for decision in decisions:
            try:
                deployment = decision['deployment']
                current_scale = await self.get_current_replicas(deployment)
                
                if decision['action'] == 'scale_up':
                    new_replicas = min(current_scale + 1, 10)  # Max 10 replicas
                elif decision['action'] == 'scale_down':
                    new_replicas = max(current_scale - 1, 1)  # Min 1 replica
                else:
                    continue
                
                if new_replicas != current_scale:
                    await self.scale_deployment(deployment, new_replicas)
                    logger.info(f"Scaled {deployment} from {current_scale} to {new_replicas}: {decision['reason']}")
                    
            except Exception as e:
                logger.error(f"Scaling error: {str(e)}")
    
    async def get_current_replicas(self, deployment_name: str) -> int:
        """Get current replica count for deployment"""
        try:
            deployment = self.apps_v1.read_namespaced_deployment(
                name=deployment_name,
                namespace='5g-anomaly-detection'
            )
            return deployment.spec.replicas
        except Exception as e:
            logger.error(f"Error getting replicas for {deployment_name}: {str(e)}")
            return 1
    
    async def scale_deployment(self, deployment_name: str, replicas: int):
        """Scale deployment to specified replica count"""
        try:
            # Get current deployment
            deployment = self.apps_v1.read_namespaced_deployment(
                name=deployment_name,
                namespace='5g-anomaly-detection'
            )
            
            # Update replicas
            deployment.spec.replicas = replicas
            
            # Patch deployment
            self.apps_v1.patch_namespaced_deployment(
                name=deployment_name,
                namespace='5g-anomaly-detection',
                body=deployment
            )
            
        except Exception as e:
            logger.error(f"Error scaling {deployment_name}: {str(e)}")
    
    def _parse_prometheus_result(self, result):
        """Parse Prometheus query result"""
        if not result:
            return {}
        
        try:
            return {
                'value': float(result[0]['value'][1]),
                'labels': result[0]['metric']
            }
        except:
            return {}
