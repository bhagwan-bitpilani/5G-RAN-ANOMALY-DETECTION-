from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import asyncio
from typing import List, Dict, Optional, Any
import json
import os
import time
from prometheus_client import make_asgi_app, Counter, Histogram, generate_latest
from collections import defaultdict

app = FastAPI(
    title="5G NR KPI Anomaly Detection",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add Prometheus metrics
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

# Custom metrics
login_attempts = Counter('login_attempts_total', 'Total login attempts', ['status'])
kpi_processed = Counter('kpi_processed_total', 'Total KPIs processed')
anomalies_detected = Counter('anomalies_detected_total', 'Total anomalies detected', ['kpi_type'])

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Enhanced in-memory storage for demo
cells_data = []
kpi_data = []
anomalies = []

# KPI Configuration
KPI_CONFIG = {
    'nr_ue_throughput': {'name': 'NR UE Throughput', 'unit': 'Mbps', 'threshold_low': 50, 'threshold_high': 200},
    'downlink_ue_throughput': {'name': 'Downlink UE Throughput', 'unit': 'Mbps', 'threshold_low': 40, 'threshold_high': 180},
    'downlink_prb_utilization': {'name': 'Downlink PRB Utilization', 'unit': '%', 'threshold_low': 0, 'threshold_high': 80},
    'data_session_success_rate': {'name': 'Data Session Setup Success Rate', 'unit': '%', 'threshold_low': 95, 'threshold_high': 100},
    'endc_add_setup_success_rate': {'name': 'ENDC ADD Setup Success Rate', 'unit': '%', 'threshold_low': 90, 'threshold_high': 100},
    'inter_sgnb_change_success_rate': {'name': 'Inter SgNB Change Success Rate', 'unit': '%', 'threshold_low': 92, 'threshold_high': 100},
    'maximum_active_endc_user': {'name': 'Maximum Active ENDC USER', 'unit': 'users', 'threshold_low': 0, 'threshold_high': 100},
    'latency': {'name': 'Latency', 'unit': 'ms', 'threshold_low': 0, 'threshold_high': 20},
    'downlink_latency': {'name': 'Downlink Latency', 'unit': 'ms', 'threshold_low': 0, 'threshold_high': 25},
    'downlink_payload_gb': {'name': 'Downlink Payload', 'unit': 'GB', 'threshold_low': 0, 'threshold_high': 50}
}

@app.on_event("startup")
async def startup_event():
    print("🚀 Starting 5G NR KPI Anomaly Detection Backend v2.0...")
    print("📊 Initializing services with enhanced KPIs...")
    # Generate sample data for demo
    generate_sample_cells()
    generate_sample_kpis()
    print("✅ Backend ready with enhanced KPIs!")

@app.get("/")
async def root():
    return {
        "message": "5G NR KPI Anomaly Detection API v2.0",
        "status": "running",
        "timestamp": datetime.utcnow().isoformat(),
        "kpis_supported": list(KPI_CONFIG.keys()),
        "endpoints": {
            "docs": "/docs",
            "health": "/health",
            "login": "/api/auth/login",
            "dashboard": "/api/dashboard/combined",
            "kpi_stats": "/api/kpi/stats",
            "cell_anomalies": "/api/cells/{cell_id}/anomalies"
        }
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy", 
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
        "kpis_supported": len(KPI_CONFIG),
        "services": {
            "database": "in_memory",
            "anomaly_detection": "active",
            "kpi_processing": "active"
        }
    }

@app.post("/api/auth/login")
async def login(
    username: str = Form(..., description="Username"),
    password: str = Form(..., description="Password")
):
    print(f"🔐 Login attempt for user: {username}")
    
    # Track login attempt
    login_attempts.labels(status='attempt').inc()
    
    # Simple authentication for demo
    if username == "admin" and password == "admin":
        login_attempts.labels(status='success').inc()
        print("✅ Login successful")
        return {
            "access_token": "demo-token-12345",
            "token_type": "bearer",
            "user": {"username": "admin", "role": "administrator"}
        }
    else:
        login_attempts.labels(status='failed').inc()
        print("❌ Login failed - invalid credentials")
        raise HTTPException(
            status_code=401, 
            detail="Invalid credentials. Use admin/admin for demo."
        )

@app.get("/api/kpi/config")
async def get_kpi_config():
    """Get KPI configuration including thresholds and units"""
    return KPI_CONFIG

@app.get("/api/kpi/stats")
async def get_kpi_stats(
    kpi_type: Optional[str] = Query(None, description="Filter by KPI type"),
    cell_id: Optional[str] = Query(None, description="Filter by cell ID"),
    time_range: Optional[str] = Query("24h", description="Time range: 1h, 24h, 7d")
):
    """Get statistics for KPIs and anomalies"""
    
    # Calculate time filter
    now = datetime.utcnow()
    if time_range == "1h":
        time_filter = now - timedelta(hours=1)
    elif time_range == "7d":
        time_filter = now - timedelta(days=7)
    else:  # 24h default
        time_filter = now - timedelta(hours=24)
    
    # Filter anomalies
    filtered_anomalies = [
        a for a in anomalies 
        if datetime.fromisoformat(a['detected_at'].replace('Z', '+00:00')) >= time_filter
        and (not kpi_type or a['kpi_type'] == kpi_type)
        and (not cell_id or a.get('cell_id') == cell_id)
    ]
    
    # Filter KPIs
    filtered_kpis = [
        k for k in kpi_data 
        if datetime.fromisoformat(k['timestamp'].replace('Z', '+00:00')) >= time_filter
        and (not cell_id or k.get('cell_id') == cell_id)
    ]
    
    # Calculate statistics per KPI type
    kpi_stats = {}
    anomaly_stats = defaultdict(lambda: {'count': 0, 'cells': set(), 'avg_score': 0, 'scores': []})
    
    for anomaly in filtered_anomalies:
        kpi_type_anom = anomaly['kpi_type']
        anomaly_stats[kpi_type_anom]['count'] += 1
        anomaly_stats[kpi_type_anom]['cells'].add(anomaly.get('cell_id', 'unknown'))
        anomaly_stats[kpi_type_anom]['scores'].append(anomaly['anomaly_score'])
    
    # Calculate averages
    for kpi_type_stat in anomaly_stats:
        stats = anomaly_stats[kpi_type_stat]
        stats['avg_score'] = round(sum(stats['scores']) / len(stats['scores']), 3) if stats['scores'] else 0
        stats['unique_cells'] = len(stats['cells'])
        stats['cells_list'] = list(stats['cells'])
        del stats['scores']
        del stats['cells']
    
    # Calculate KPI value statistics
    for kpi in filtered_kpis:
        for kpi_field, value in kpi.items():
            if kpi_field in KPI_CONFIG and isinstance(value, (int, float)):
                if kpi_field not in kpi_stats:
                    kpi_stats[kpi_field] = {'values': [], 'timestamps': []}
                kpi_stats[kpi_field]['values'].append(value)
                kpi_stats[kpi_field]['timestamps'].append(kpi['timestamp'])
    
    # Calculate min, max, avg for each KPI
    for kpi_field, data in kpi_stats.items():
        values = data['values']
        kpi_stats[kpi_field] = {
            'count': len(values),
            'min': round(min(values), 2) if values else 0,
            'max': round(max(values), 2) if values else 0,
            'avg': round(sum(values) / len(values), 2) if values else 0,
            'latest_timestamp': data['timestamps'][-1] if data['timestamps'] else None
        }
    
    return {
        "time_range": time_range,
        "total_anomalies": len(filtered_anomalies),
        "total_kpis": len(filtered_kpis),
        "anomaly_stats": dict(anomaly_stats),
        "kpi_stats": kpi_stats,
        "filters": {
            "kpi_type": kpi_type,
            "cell_id": cell_id
        }
    }

@app.get("/api/cells/{cell_id}/anomalies")
async def get_cell_anomalies(
    cell_id: str,
    kpi_type: Optional[str] = Query(None, description="Filter by KPI type"),
    limit: int = Query(50, description="Number of anomalies to return")
):
    """Get anomalies for a specific cell"""
    cell_anomalies = [
        a for a in anomalies 
        if a.get('cell_id') == cell_id
        and (not kpi_type or a['kpi_type'] == kpi_type)
    ]
    
    # Sort by detection time, most recent first
    cell_anomalies.sort(key=lambda x: x['detected_at'], reverse=True)
    
    return {
        "cell_id": cell_id,
        "total_anomalies": len(cell_anomalies),
        "anomalies": cell_anomalies[:limit],
        "kpi_types": list(set(a['kpi_type'] for a in cell_anomalies))
    }

@app.get("/api/dashboard/combined")
async def get_combined_dashboard(
    kpi_type: Optional[str] = Query(None, description="Filter by KPI type"),
    cell_id: Optional[str] = Query(None, description="Filter by cell ID"),
    time_range: str = Query("24h", description="Time range: 1h, 24h, 7d")
):
    print("📈 Generating enhanced dashboard data...")
    
    # Generate sample data if empty
    if not cells_data:
        generate_sample_cells()
    if not kpi_data:
        generate_sample_kpis()
    
    # Calculate time filter
    now = datetime.utcnow()
    if time_range == "1h":
        time_filter = now - timedelta(hours=1)
    elif time_range == "7d":
        time_filter = now - timedelta(days=7)
    else:  # 24h default
        time_filter = now - timedelta(hours=24)
    
    # Filter KPIs
    filtered_kpis = [
        k for k in kpi_data 
        if datetime.fromisoformat(k['timestamp'].replace('Z', '+00:00')) >= time_filter
        and (not kpi_type or kpi_type in k['anomaly_flags'])
        and (not cell_id or k.get('cell_id') == cell_id)
    ]
    
    # Filter anomalies
    filtered_anomalies = [
        a for a in anomalies 
        if datetime.fromisoformat(a['detected_at'].replace('Z', '+00:00')) >= time_filter
        and (not kpi_type or a['kpi_type'] == kpi_type)
        and (not cell_id or a.get('cell_id') == cell_id)
        and not a.get('is_resolved', False)
    ]
    
    # Calculate statistics
    total_cells = len(cells_data)
    active_anomalies = len(filtered_anomalies)
    
    # Band distribution
    band_stats = {}
    for cell in cells_data:
        band = cell.get('band', 'Unknown')
        band_stats[band] = band_stats.get(band, 0) + 1
    
    # Anomaly distribution by KPI type
    anomaly_by_kpi = {}
    for anomaly in filtered_anomalies:
        kpi_type_anom = anomaly['kpi_type']
        anomaly_by_kpi[kpi_type_anom] = anomaly_by_kpi.get(kpi_type_anom, 0) + 1
    
    # Anomaly distribution by cell
    anomaly_by_cell = {}
    for anomaly in filtered_anomalies:
        cell = anomaly.get('cell_id', 'unknown')
        anomaly_by_cell[cell] = anomaly_by_cell.get(cell, 0) + 1
    
    return {
        "summary": {
            "total_cells": total_cells,
            "anomalies_24h": active_anomalies,
            "system_health": "healthy",
            "band_distribution": band_stats,
            "last_updated": datetime.utcnow().isoformat()
        },
        "kpis": filtered_kpis[-100:],  # Last 100 KPIs
        "anomalies": filtered_anomalies[-20:],  # Last 20 anomalies
        "statistics": {
            "total_kpis_processed": len(kpi_data),
            "total_anomalies_detected": len(anomalies),
            "anomaly_resolution_rate": round((len([a for a in anomalies if a.get('is_resolved', False)]) / len(anomalies) * 100) if anomalies else 100, 1),
            "anomaly_by_kpi": anomaly_by_kpi,
            "anomaly_by_cell": anomaly_by_cell
        },
        "filters": {
            "kpi_type": kpi_type,
            "cell_id": cell_id,
            "time_range": time_range
        },
        "kpi_config": KPI_CONFIG
    }

@app.post("/api/kpi/stream")
async def stream_kpi_data(kpi_data_input: Dict):
    try:
        print("📊 Processing enhanced KPI data stream...")
        kpi_processed.inc()
        
        # Enhanced anomaly detection for all KPIs
        anomaly_flags = {}
        anomaly_score = 0.0
        anomaly_reasons = []
        
        # Check each KPI against its thresholds
        for kpi_field, config in KPI_CONFIG.items():
            value = kpi_data_input.get(kpi_field)
            if value is not None:
                threshold_low = config['threshold_low']
                threshold_high = config['threshold_high']
                
                if value < threshold_low or value > threshold_high:
                    anomaly_flags[kpi_field] = True
                    if value < threshold_low:
                        score_component = (threshold_low - value) / threshold_low
                        anomaly_reasons.append(f"Low {config['name']}: {value:.1f}{config['unit']}")
                    else:
                        score_component = (value - threshold_high) / threshold_high
                        anomaly_reasons.append(f"High {config['name']}: {value:.1f}{config['unit']}")
                    
                    anomaly_score = max(anomaly_score, min(score_component, 1.0))
                else:
                    anomaly_flags[kpi_field] = False
        
        # Determine if overall anomaly
        is_anomaly = any(anomaly_flags.values())
        
        kpi_record = {
            **kpi_data_input,
            'id': len(kpi_data) + 1,
            'timestamp': datetime.utcnow().isoformat(),
            'processed_at': datetime.utcnow().isoformat(),
            'anomaly_flags': anomaly_flags,
            'anomaly_score_overall': round(anomaly_score, 3)
        }
        kpi_data.append(kpi_record)
        
        response_data = {
            "status": "processed", 
            "anomaly_detected": is_anomaly,
            "anomaly_score": round(anomaly_score, 3),
            "anomaly_flags": anomaly_flags,
            "kpi_id": len(kpi_data)
        }
        
        if is_anomaly:
            # Create individual anomaly records for each failed KPI
            for kpi_field, is_anomalous in anomaly_flags.items():
                if is_anomalous:
                    anomalies_detected.labels(kpi_type=kpi_field).inc()
                    anomaly_record = {
                        'id': len(anomalies) + 1,
                        'kpi_id': len(kpi_data),
                        'anomaly_score': anomaly_score,
                        'detected_at': datetime.utcnow().isoformat(),
                        'kpi_type': kpi_field,
                        'kpi_value': kpi_data_input.get(kpi_field),
                        'cell_id': kpi_data_input.get('cell_id', 'unknown'),
                        'is_resolved': False,
                        'reasons': anomaly_reasons,
                        'threshold_low': KPI_CONFIG[kpi_field]['threshold_low'],
                        'threshold_high': KPI_CONFIG[kpi_field]['threshold_high']
                    }
                    anomalies.append(anomaly_record)
            
            response_data['anomaly_reasons'] = anomaly_reasons
            response_data['anomaly_count'] = len(anomalies)
            print(f"🚨 Anomaly detected! Score: {anomaly_score:.3f}, Reasons: {anomaly_reasons}")
        else:
            print(f"✅ KPI processed successfully - No anomalies")
        
        return response_data
        
    except Exception as e:
        print(f"❌ KPI processing error: {str(e)}")
        raise HTTPException(500, f"Error processing KPI: {str(e)}")

# Existing endpoints for cells and upload remain the same
@app.get("/api/cells")
async def get_cells():
    if not cells_data:
        generate_sample_cells()
    
    return {
        "cells": cells_data,
        "total_count": len(cells_data),
        "bands": list(set(cell['band'] for cell in cells_data))
    }

@app.post("/api/upload/cells")
async def upload_cells(file: UploadFile = File(...)):
    try:
        print(f"📤 Uploading cells file: {file.filename}")
        
        if file.filename.endswith('.xlsx'):
            df = pd.read_excel(file.file)
        elif file.filename.endswith('.csv'):
            df = pd.read_csv(file.file)
        else:
            raise HTTPException(400, "Only Excel or CSV files are supported")
        
        # Process cells data
        uploaded_count = 0
        for _, row in df.iterrows():
            cell_data = {
                'id': len(cells_data) + 1,
                'cell_id': row.get('cell_id', f'CELL_{len(cells_data) + 1}'),
                'band': row.get('band', 'NR2600'),
                'location': row.get('location', 'Unknown'),
                'sector': int(row.get('sector', 1)),
                'status': 'active',
                'created_at': datetime.utcnow().isoformat()
            }
            cells_data.append(cell_data)
            uploaded_count += 1
        
        print(f"✅ Successfully processed {uploaded_count} cells")
        return {
            "message": f"Successfully uploaded {uploaded_count} cells",
            "total_cells": len(cells_data),
            "uploaded_count": uploaded_count
        }
    except Exception as e:
        print(f"❌ Upload error: {str(e)}")
        raise HTTPException(500, f"Error processing file: {str(e)}")

def generate_sample_cells():
    """Generate sample cell data for demo"""
    print("🔧 Generating sample cells data...")
    
    # Clear existing data
    cells_data.clear()
    
    # Generate NR2600 cells
    for i in range(1, 51):
        cells_data.append({
            'id': i,
            'cell_id': f'NR2600_{i:03d}',
            'band': 'NR2600',
            'location': f'Sector_{(i-1)//10 + 1}',
            'sector': ((i-1) % 3) + 1,
            'latitude': 40.7128 + (i * 0.001),
            'longitude': -74.0060 + (i * 0.001),
            'status': 'active',
            'created_at': datetime.utcnow().isoformat()
        })
    
    # Generate NR700 cells
    for i in range(1, 51):
        cells_data.append({
            'id': i + 50,
            'cell_id': f'NR700_{i:03d}',
            'band': 'NR700',
            'location': f'Sector_{(i-1)//10 + 1}',
            'sector': ((i-1) % 3) + 1,
            'latitude': 40.7128 - (i * 0.001),
            'longitude': -74.0060 - (i * 0.001),
            'status': 'active',
            'created_at': datetime.utcnow().isoformat()
        })
    
    print(f"✅ Generated {len(cells_data)} sample cells")

def generate_sample_kpis():
    """Generate enhanced sample KPI data for demo"""
    print("🔧 Generating enhanced sample KPI data...")
    
    # Clear existing data
    kpi_data.clear()
    anomalies.clear()
    
    bands = ['NR2600', 'NR700']
    
    for i in range(200):  # More sample data
        cell_id = f'{np.random.choice(bands)}_{np.random.randint(1, 51):03d}'
        
        # Create realistic KPI data with occasional anomalies
        base_values = {
            'nr_ue_throughput': np.random.normal(120, 30),
            'downlink_ue_throughput': np.random.normal(100, 25),
            'downlink_prb_utilization': np.random.normal(50, 15),
            'data_session_success_rate': np.random.normal(98, 1.5),
            'endc_add_setup_success_rate': np.random.normal(96, 2),
            'inter_sgnb_change_success_rate': np.random.normal(95, 2.5),
            'maximum_active_endc_user': np.random.poisson(45),
            'latency': np.random.normal(12, 4),
            'downlink_latency': np.random.normal(15, 5),
            'downlink_payload_gb': np.random.normal(25, 10)
        }
        
        # Introduce anomalies in 15% of cases
        is_anomaly = np.random.random() < 0.15
        
        if is_anomaly:
            # Randomly degrade some KPIs
            anomaly_kpis = np.random.choice(list(base_values.keys()), size=np.random.randint(1, 4), replace=False)
            for kpi in anomaly_kpis:
                if 'success_rate' in kpi or 'utilization' in kpi:
                    base_values[kpi] *= np.random.uniform(0.7, 0.9)  # Reduce success rates
                elif 'latency' in kpi:
                    base_values[kpi] *= np.random.uniform(1.5, 3.0)  # Increase latency
                elif 'throughput' in kpi:
                    base_values[kpi] *= np.random.uniform(0.4, 0.7)  # Reduce throughput
                elif kpi == 'maximum_active_endc_user':
                    base_values[kpi] *= np.random.uniform(1.3, 2.0)  # Increase user count
                elif kpi == 'downlink_payload_gb':
                    base_values[kpi] *= np.random.uniform(1.5, 3.0)  # Increase payload
        
        kpi_record = {
            'id': i + 1,
            'cell_id': cell_id,
            'kpi_type': 'comprehensive',
            'timestamp': (datetime.utcnow() - timedelta(minutes=200-i)).isoformat(),
            **{k: round(v, 2) for k, v in base_values.items()}
        }
        
        # Add anomaly flags based on thresholds
        anomaly_flags = {}
        for kpi_field, value in base_values.items():
            if kpi_field in KPI_CONFIG:
                threshold_low = KPI_CONFIG[kpi_field]['threshold_low']
                threshold_high = KPI_CONFIG[kpi_field]['threshold_high']
                anomaly_flags[kpi_field] = value < threshold_low or value > threshold_high
        
        kpi_record['anomaly_flags'] = anomaly_flags
        kpi_record['anomaly_score_overall'] = round(np.random.uniform(0.1, 0.9) if is_anomaly else 0.0, 3)
        
        kpi_data.append(kpi_record)
    
    print(f"✅ Generated {len(kpi_data)} enhanced sample KPIs")

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Enhanced 5G NR KPI Anomaly Detection Backend Server...")
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000, 
        log_level="info",
        access_log=True
    )
