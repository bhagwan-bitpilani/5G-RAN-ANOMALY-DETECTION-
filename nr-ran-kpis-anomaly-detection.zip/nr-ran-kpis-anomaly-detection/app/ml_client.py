"""
ML Service Client for communicating with ML service
"""
import aiohttp
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class MLClient:
    """Client for ML service communication"""
    
    def __init__(self, base_url: str = "http://ml-service:8001"):
        self.base_url = base_url
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def detect_anomalies(self, kpi_data: Dict[str, Any]) -> Dict[str, Any]:
        """Detect anomalies using ML service"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            async with self.session.post(
                f"{self.base_url}/api/ml/detect",
                json=kpi_data,
                timeout=30
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error_text = await response.text()
                    logger.error(f"ML service error: {error_text}")
                    return await self.fallback_anomaly_detection(kpi_data)
                    
        except Exception as e:
            logger.error(f"ML service communication failed: {str(e)}")
            return await self.fallback_anomaly_detection(kpi_data)
    
    async def train_model(self, training_data: Dict[str, Any]) -> Dict[str, Any]:
        """Train ML model with new data"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            async with self.session.post(
                f"{self.base_url}/api/ml/train",
                json=training_data,
                timeout=60
            ) as response:
                return await response.json()
                
        except Exception as e:
            logger.error(f"Model training request failed: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    async def get_model_info(self) -> Dict[str, Any]:
        """Get information about loaded ML models"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            async with self.session.get(
                f"{self.base_url}/api/ml/models",
                timeout=10
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    return {"models": {}}
                    
        except Exception as e:
            logger.error(f"Failed to get model info: {str(e)}")
            return {"models": {}}
    
    async def fallback_anomaly_detection(self, kpi_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback anomaly detection when ML service is unavailable"""
        logger.warning("Using fallback anomaly detection")
        
        kpi_type = kpi_data.get('kpi_type', 'unknown')
        values = kpi_data.get('values', [])
        
        # Simple threshold-based detection as fallback
        thresholds = {
            'throughput': (50, 200),
            'latency': (0, 25),
            'success_rate': (95, 100),
            'utilization': (0, 80),
            'user_count': (0, 100),
            'payload': (0, 50)
        }
        
        threshold_low, threshold_high = thresholds.get(kpi_type, (0, 100))
        
        results = []
        for i, value in enumerate(values):
            is_anomaly = value < threshold_low or value > threshold_high
            
            if value < threshold_low:
                score = (threshold_low - value) / threshold_low
            elif value > threshold_high:
                score = (value - threshold_high) / threshold_high
            else:
                score = 0.0
            
            results.append({
                'index': i,
                'is_anomaly': is_anomaly,
                'anomaly_score': min(1.0, max(0.0, score)),
                'value': value,
                'timestamp': datetime.utcnow().isoformat()
            })
        
        return {
            "kpi_type": kpi_type,
            "total_predictions": len(results),
            "anomalies_detected": sum(1 for r in results if r['is_anomaly']),
            "results": results,
            "model_performance": {"is_fallback": True}
        }
    
    async def health_check(self) -> bool:
        """Check if ML service is healthy"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            async with self.session.get(
                f"{self.base_url}/health",
                timeout=5
            ) as response:
                return response.status == 200
                
        except Exception:
            return False

# Global ML client instance
ml_client = MLClient()
