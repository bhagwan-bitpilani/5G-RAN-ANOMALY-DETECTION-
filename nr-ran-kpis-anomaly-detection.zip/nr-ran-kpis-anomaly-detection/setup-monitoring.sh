#!/bin/bash

echo "🚀 Setting up Enhanced 5G NR Monitoring..."

# Create necessary directories
mkdir -p monitoring/grafana/dashboards
mkdir -p monitoring/alertmanager

echo "📊 Building and starting monitoring services..."
docker-compose down

echo "1. Building Backend Service..."
docker-compose build backend

echo "3. Building Frontend..."
docker-compose build frontend

echo "4. Starting All Services..."
docker-compose up -d

echo "⏳ Waiting for services to initialize..."
sleep 30

echo "🔍 Checking service status..."
docker-compose ps

echo "✅ Setting up Grafana datasource..."
# Wait for Grafana to be ready
until curl -s http://localhost:3002/api/health > /dev/null; do
    echo "Waiting for Grafana..."
    sleep 5
done

# Create Prometheus datasource in Grafana
curl -X POST "http://admin:admin@localhost:3002/api/datasources" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Prometheus",
    "type": "prometheus",
    "url": "http://prometheus:9090",
    "access": "proxy",
    "isDefault": true
  }'

echo ""
echo "🎉 Enhanced Monitoring Setup Complete!"
echo ""
echo "🌐 Access URLs:"
echo "   Frontend:         http://localhost:3000"
echo "   Backend API:      http://localhost:8000"
echo "   Grafana:          http://localhost:3002 (admin/admin)"
echo "   Prometheus:       http://localhost:19090"
echo "   Alertmanager:     http://localhost:19093"
echo "   Node Exporter:    http://localhost:19100"
echo "   cAdvisor:         http://localhost:18080"
echo ""
echo "📊 Pre-configured Dashboards:"
echo "   - 5G NR KPI Overview"
echo "   - 5G NR Anomaly Detection" 
echo "   - 5G NR Cell-Level Analysis"
echo ""
echo "🔔 Alerting:"
echo "   - KPI degradation alerts"
echo "   - Anomaly detection alerts"
echo "   - Resource utilization alerts"
echo ""
echo "📈 Metrics Collected:"
echo "   - All 10 enhanced KPIs with thresholds"
echo "   - Anomaly scores and detection rates"
echo "   - System resource utilization"
echo "   - Container performance metrics"
