import React from 'react'
import { Layout, Menu, Button, theme } from 'antd'
import { 
  DashboardOutlined, 
  WifiOutlined, 
  UploadOutlined,
  LogoutOutlined,
  BarChartOutlined
} from '@ant-design/icons'
import { useNavigate, useLocation } from 'react-router-dom'

const { Header: AntHeader } = Layout

const Header = ({ onLogout }) => {
  const navigate = useNavigate()
  const location = useLocation()
  const { token: { colorBgContainer } } = theme.useToken()

  const menuItems = [
    {
      key: '/dashboard',
      icon: <DashboardOutlined />,
      label: 'Dashboard',
    },
    {
      key: '/cell-analysis',
      icon: <BarChartOutlined />,
      label: 'Cell Analysis',
    },
    {
      key: '/cells',
      icon: <WifiOutlined />,
      label: 'NR Cells',
    },
    {
      key: '/upload',
      icon: <UploadOutlined />,
      label: 'Upload',
    },
  ]

  const handleMenuClick = ({ key }) => {
    navigate(key)
  }

  return (
    <AntHeader 
      style={{ 
        display: 'flex', 
        alignItems: 'center',
        background: colorBgContainer,
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        padding: '0 24px'
      }}
    >
      <div style={{ 
        fontSize: '20px', 
        fontWeight: 'bold',
        marginRight: '40px',
        color: '#1890ff'
      }}>
        5G NR Monitor v2.0
      </div>
      
      <Menu
        mode="horizontal"
        selectedKeys={[location.pathname]}
        items={menuItems}
        style={{ 
          flex: 1, 
          border: 'none',
          background: 'transparent'
        }}
        onClick={handleMenuClick}
      />
      
      <Button 
        icon={<LogoutOutlined />} 
        onClick={onLogout}
        type="text"
      >
        Logout
      </Button>
    </AntHeader>
  )
}

export default Header
