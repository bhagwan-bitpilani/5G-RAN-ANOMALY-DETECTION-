import React, { useState } from 'react'
import { Upload, Button, message, Card, Alert, Space } from 'antd'
import { UploadOutlined, DownloadOutlined } from '@ant-design/icons'
import axios from 'axios'

const UploadPage = () => {
  const [uploading, setUploading] = useState(false)

  const handleUpload = async (file) => {
    setUploading(true)
    const formData = new FormData()
    formData.append('file', file)

    try {
      const response = await axios.post('/api/upload/cells', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
      message.success(response.data.message)
    } catch (error) {
      message.error('Upload failed! Using demo mode - data loaded in memory.')
    } finally {
      setUploading(false)
    }
    return false
  }

  const downloadTemplate = () => {
    const templateData = [
      { cell_id: 'NR2600_001', band: 'NR2600', location: 'Sector_1', sector: 1 },
      { cell_id: 'NR700_001', band: 'NR700', location: 'Sector_2', sector: 2 },
    ]
    
    const csv = 'cell_id,band,location,sector\n' + 
      templateData.map(row => 
        `${row.cell_id},${row.band},${row.location},${row.sector}`
      ).join('\n')
    
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'nr_cells_template.csv'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
  }

  return (
    <div style={{ padding: '24px' }}>
      <Card title="Upload NR Cells Data" bordered={false} className="dashboard-card">
        <Alert
          message="Upload Excel or CSV file with NR cells information"
          description="The file should contain columns: cell_id, band, location, sector"
          type="info"
          showIcon
          style={{ marginBottom: 24 }}
        />
        
        <Space direction="vertical" style={{ width: '100%' }}>
          <Upload
            beforeUpload={handleUpload}
            accept=".xlsx,.xls,.csv"
            showUploadList={false}
          >
            <Button 
              icon={<UploadOutlined />} 
              loading={uploading}
              type="primary"
              size="large"
            >
              {uploading ? 'Uploading' : 'Upload Cells File'}
            </Button>
          </Upload>

          <Button 
            icon={<DownloadOutlined />} 
            onClick={downloadTemplate}
            size="large"
          >
            Download Template
          </Button>
        </Space>
      </Card>
    </div>
  )
}

export default UploadPage
