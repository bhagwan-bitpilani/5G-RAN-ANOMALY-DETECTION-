import React from 'react'
import { Card, Form, Input, Button, message, Alert } from 'antd'
import { UserOutlined, LockOutlined, WarningOutlined } from '@ant-design/icons'
import axios from 'axios'
import '../styles/App.css'

const Login = ({ onLogin }) => {
  const [loading, setLoading] = React.useState(false)
  const [apiStatus, setApiStatus] = React.useState('checking')

  // Check backend health on component mount
  React.useEffect(() => {
    checkBackendHealth()
  }, [])

  const checkBackendHealth = async () => {
    try {
      const response = await axios.get('/api/health', { timeout: 5000 })
      if (response.data.status === 'healthy') {
        setApiStatus('healthy')
      } else {
        setApiStatus('unhealthy')
      }
    } catch (error) {
      console.error('Backend health check failed:', error)
      setApiStatus('unreachable')
    }
  }

  const onFinish = async (values) => {
    setLoading(true)
    try {
      // Use URLSearchParams for proper form data
      const formData = new URLSearchParams()
      formData.append('username', values.username)
      formData.append('password', values.password)

      const response = await axios.post('/api/auth/login', formData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        timeout: 10000
      })
      
      if (response.data.access_token) {
        localStorage.setItem('token', response.data.access_token)
        localStorage.setItem('user', JSON.stringify(response.data.user || { username: values.username }))
        message.success('Login successful!')
        onLogin()
      } else {
        message.error('Invalid response from server')
      }
    } catch (error) {
      console.error('Login error:', error)
      
      if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        message.error('Backend server is not responding. Please try again later.')
      } else if (error.response?.status === 401) {
        message.error('Invalid username or password. Use admin/admin for demo.')
      } else if (error.response?.status === 422) {
        message.error('Login format error. Using demo mode...')
        demoLogin()
      } else if (error.response?.status >= 500) {
        message.error('Server error. Please try again later.')
      } else {
        message.error('Connection failed. Using demo mode...')
        demoLogin()
      }
    } finally {
      setLoading(false)
    }
  }

  const demoLogin = () => {
    localStorage.setItem('token', 'demo-token-' + Date.now())
    localStorage.setItem('user', JSON.stringify({ username: 'demo', role: 'administrator' }))
    message.success('Logged in with demo account!')
    onLogin()
  }

  return (
    <div className="login-container">
      <Card 
        title="5G NR KPI Anomaly Detection" 
        style={{ width: 450 }}
        headStyle={{ textAlign: 'center', fontSize: '24px', fontWeight: 'bold', padding: '20px' }}
        bodyStyle={{ padding: '24px' }}
      >
        {apiStatus === 'unreachable' && (
          <Alert
            message="Backend Connection Issue"
            description="Cannot connect to backend server. Using demo mode with sample data."
            type="warning"
            showIcon
            icon={<WarningOutlined />}
            style={{ marginBottom: 16 }}
            action={
              <Button size="small" type="primary" onClick={checkBackendHealth}>
                Retry
              </Button>
            }
          />
        )}

        {apiStatus === 'healthy' && (
          <Alert
            message="Backend Connected"
            description="Server is running properly. Use admin/admin to login."
            type="success"
            showIcon
            style={{ marginBottom: 16 }}
          />
        )}

        <Form 
          name="login" 
          onFinish={onFinish} 
          autoComplete="off"
          layout="vertical"
          initialValues={{ username: 'admin', password: 'admin' }}
        >
          <Form.Item 
            name="username" 
            label="Username"
            rules={[{ required: true, message: 'Please input your username!' }]}
          >
            <Input 
              prefix={<UserOutlined />} 
              placeholder="Enter username" 
              size="large"
            />
          </Form.Item>
          
          <Form.Item 
            name="password" 
            label="Password"
            rules={[{ required: true, message: 'Please input your password!' }]}
          >
            <Input.Password 
              prefix={<LockOutlined />} 
              placeholder="Enter password" 
              size="large"
            />
          </Form.Item>
          
          <Form.Item>
            <Button 
              type="primary" 
              htmlType="submit" 
              style={{ width: '100%' }}
              size="large"
              loading={loading}
            >
              {loading ? 'Logging in...' : 'Log in'}
            </Button>
          </Form.Item>
        </Form>

        <div style={{ textAlign: 'center', marginTop: '16px' }}>
          <div style={{ color: '#666', marginBottom: '12px' }}>
            <p><strong>Demo credentials:</strong> admin / admin</p>
            <p style={{ fontSize: '12px', marginTop: '8px' }}>
              Pre-filled for your convenience
            </p>
          </div>
          
          <Button 
            type="dashed" 
            style={{ width: '100%' }}
            onClick={demoLogin}
            size="large"
          >
            Use Demo Mode (No Backend Required)
          </Button>
        </div>

        <div style={{ marginTop: '20px', padding: '12px', background: '#f5f5f5', borderRadius: '6px' }}>
          <div style={{ fontSize: '12px', color: '#666', textAlign: 'center' }}>
            <p><strong>Troubleshooting:</strong></p>
            <p>• Username and password are pre-filled</p>
            <p>• Use admin/admin for real backend login</p>
            <p>• Demo mode works without backend connection</p>
          </div>
        </div>
      </Card>
    </div>
  )
}

export default Login
