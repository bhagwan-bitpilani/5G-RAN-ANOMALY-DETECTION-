import React, { useState, useEffect } from 'react'
import { 
  Card, Row, Col, Statistic, Alert, Table, Tag, Spin, 
  Select, DatePicker, Button, Tabs, Radio, Space 
} from 'antd'
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell 
} from 'recharts'
import { 
  WifiOutlined, ExclamationCircleOutlined, CheckCircleOutlined,
  FilterOutlined, ReloadOutlined, BarChartOutlined 
} from '@ant-design/icons'
import axios from 'axios'
import dayjs from 'dayjs'

const { Option } = Select
const { RangePicker } = DatePicker
const { TabPane } = Tabs

const Dashboard = () => {
  const [dashboardData, setDashboardData] = useState(null)
  const [kpiStats, setKpiStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [anomalies, setAnomalies] = useState([])
  const [filters, setFilters] = useState({
    kpiType: null,
    cellId: null,
    timeRange: '24h'
  })
  const [kpiConfig, setKpiConfig] = useState({})
  const [activeTab, setActiveTab] = useState('overview')

  useEffect(() => {
    fetchKpiConfig()
    fetchDashboardData()
    const interval = setInterval(fetchDashboardData, 30000)
    return () => clearInterval(interval)
  }, [filters])

  const fetchKpiConfig = async () => {
    try {
      const response = await axios.get('/api/kpi/config')
      setKpiConfig(response.data)
    } catch (error) {
      console.error('Error fetching KPI config:', error)
    }
  }

  const fetchDashboardData = async () => {
    try {
      const params = {}
      if (filters.kpiType) params.kpi_type = filters.kpiType
      if (filters.cellId) params.cell_id = filters.cellId
      params.time_range = filters.timeRange

      const response = await axios.get('/api/dashboard/combined', { params })
      setDashboardData(response.data)
      setAnomalies(response.data.anomalies || [])
      
      // Fetch detailed KPI stats
      const statsResponse = await axios.get('/api/kpi/stats', { params })
      setKpiStats(statsResponse.data)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
      setDashboardData(generateSampleData())
      setAnomalies(generateSampleAnomalies())
    } finally {
      setLoading(false)
    }
  }

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }

  const clearFilters = () => {
    setFilters({
      kpiType: null,
      cellId: null,
      timeRange: '24h'
    })
  }

  const generateSampleData = () => {
    return {
      summary: {
        total_cells: 100,
        anomalies_24h: 8,
        system_health: 'healthy'
      },
      statistics: {
        anomaly_by_kpi: {
          'downlink_ue_throughput': 3,
          'downlink_prb_utilization': 2,
          'latency': 1,
          'data_session_success_rate': 2
        },
        anomaly_by_cell: {
          'NR2600_001': 2,
          'NR700_015': 3,
          'NR2600_042': 1,
          'NR700_033': 2
        }
      }
    }
  }

  const generateSampleAnomalies = () => {
    return [
      {
        id: 1,
        kpi_type: 'downlink_ue_throughput',
        anomaly_score: 0.89,
        detected_at: new Date().toISOString(),
        cell_id: 'NR2600_001',
        is_resolved: false,
        kpi_value: 25.5
      },
      {
        id: 2,
        kpi_type: 'downlink_prb_utilization', 
        anomaly_score: 0.76,
        detected_at: new Date(Date.now() - 300000).toISOString(),
        cell_id: 'NR700_015',
        is_resolved: false,
        kpi_value: 92.3
      }
    ]
  }

  // Prepare data for charts
  const prepareAnomalyByKpiData = () => {
    if (!dashboardData?.statistics?.anomaly_by_kpi) return []
    return Object.entries(dashboardData.statistics.anomaly_by_kpi).map(([kpi, count]) => ({
      name: kpiConfig[kpi]?.name || kpi,
      value: count,
      kpi: kpi
    }))
  }

  const prepareAnomalyByCellData = () => {
    if (!dashboardData?.statistics?.anomaly_by_cell) return []
    return Object.entries(dashboardData.statistics.anomaly_by_cell)
      .slice(0, 10)
      .map(([cell, count]) => ({
        name: cell,
        value: count
      }))
  }

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D']

  const anomalyColumns = [
    {
      title: 'KPI Type',
      dataIndex: 'kpi_type',
      key: 'kpi_type',
      render: (kpiType) => (
        <Tag color="blue">
          {kpiConfig[kpiType]?.name || kpiType}
        </Tag>
      ),
    },
    {
      title: 'Cell ID',
      dataIndex: 'cell_id',
      key: 'cell_id',
    },
    {
      title: 'Value',
      dataIndex: 'kpi_value',
      key: 'kpi_value',
      render: (value, record) => (
        <span>
          {value} {kpiConfig[record.kpi_type]?.unit || ''}
        </span>
      ),
    },
    {
      title: 'Score',
      dataIndex: 'anomaly_score',
      key: 'score',
      render: score => (
        <Tag color={score > 0.8 ? 'red' : score > 0.6 ? 'orange' : 'yellow'}>
          {score.toFixed(3)}
        </Tag>
      ),
    },
    {
      title: 'Detected At',
      dataIndex: 'detected_at',
      key: 'detected_at',
      render: date => new Date(date).toLocaleString()
    },
  ]

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
        <Spin size="large" />
      </div>
    )
  }

  const anomalyByKpiData = prepareAnomalyByKpiData()
  const anomalyByCellData = prepareAnomalyByCellData()

  return (
    <div style={{ padding: '24px' }}>
      {/* Filters */}
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontSize: '12px', marginBottom: 4 }}>KPI Type</div>
            <Select
              placeholder="Filter by KPI"
              style={{ width: 200 }}
              value={filters.kpiType}
              onChange={(value) => handleFilterChange('kpiType', value)}
              allowClear
            >
              {Object.entries(kpiConfig).map(([key, config]) => (
                <Option key={key} value={key}>{config.name}</Option>
              ))}
            </Select>
          </div>
          
          <div>
            <div style={{ fontSize: '12px', marginBottom: 4 }}>Cell ID</div>
            <Select
              placeholder="Filter by Cell"
              style={{ width: 150 }}
              value={filters.cellId}
              onChange={(value) => handleFilterChange('cellId', value)}
              allowClear
            >
              <Option value="NR2600_001">NR2600_001</Option>
              <Option value="NR700_015">NR700_015</Option>
              <Option value="NR2600_042">NR2600_042</Option>
            </Select>
          </div>

          <div>
            <div style={{ fontSize: '12px', marginBottom: 4 }}>Time Range</div>
            <Radio.Group 
              value={filters.timeRange} 
              onChange={(e) => handleFilterChange('timeRange', e.target.value)}
            >
              <Radio.Button value="1h">1H</Radio.Button>
              <Radio.Button value="24h">24H</Radio.Button>
              <Radio.Button value="7d">7D</Radio.Button>
            </Radio.Group>
          </div>

          <Button 
            icon={<ReloadOutlined />} 
            onClick={fetchDashboardData}
            loading={loading}
          >
            Refresh
          </Button>

          <Button 
            icon={<FilterOutlined />} 
            onClick={clearFilters}
          >
            Clear Filters
          </Button>
        </div>
      </Card>

      {/* Summary Stats */}
      <Row gutter={[16, 16]}>
        <Col span={6}>
          <Card>
            <Statistic
              title="Total NR Cells"
              value={dashboardData?.summary?.total_cells || 0}
              prefix={<WifiOutlined />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="Active Anomalies"
              value={dashboardData?.summary?.anomalies_24h || 0}
              valueStyle={{ color: dashboardData?.summary?.anomalies_24h > 0 ? '#cf1322' : '#3f8600' }}
              prefix={<ExclamationCircleOutlined />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="System Health"
              value={dashboardData?.summary?.system_health === 'healthy' ? 'Healthy' : 'Degraded'}
              valueStyle={{ color: dashboardData?.summary?.system_health === 'healthy' ? '#3f8600' : '#cf1322' }}
              prefix={<CheckCircleOutlined />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="KPI Types Monitored"
              value={Object.keys(kpiConfig).length}
              suffix={`/ ${Object.keys(kpiConfig).length}`}
            />
          </Card>
        </Col>
      </Row>

      {/* Enhanced Tabs */}
      <Tabs 
        activeKey={activeTab} 
        onChange={setActiveTab}
        style={{ marginTop: 24 }}
        items={[
          {
            key: 'overview',
            label: 'Overview',
            children: (
              <Row gutter={[16, 16]}>
                <Col span={12}>
                  <Card title="Anomalies by KPI Type" bordered={false}>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={anomalyByKpiData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {anomalyByKpiData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </Card>
                </Col>

                <Col span={12}>
                  <Card title="Top Cells with Anomalies" bordered={false}>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={anomalyByCellData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="value" fill="#8884d8" name="Anomaly Count" />
                      </BarChart>
                    </ResponsiveContainer>
                  </Card>
                </Col>
              </Row>
            )
          },
          {
            key: 'anomalies',
            label: 'Recent Anomalies',
            children: (
              <Card title="Recent Anomalies" bordered={false}>
                <Table
                  dataSource={anomalies}
                  columns={anomalyColumns}
                  pagination={{ pageSize: 10 }}
                  size="small"
                  rowKey="id"
                  scroll={{ y: 400 }}
                />
              </Card>
            )
          },
          {
            key: 'stats',
            label: 'KPI Statistics',
            children: kpiStats && (
              <Card title="KPI Statistics" bordered={false}>
                <Row gutter={[16, 16]}>
                  <Col span={24}>
                    <Alert
                      message={`Time Range: ${kpiStats.time_range} | Total Anomalies: ${kpiStats.total_anomalies} | Total KPIs: ${kpiStats.total_kpis}`}
                      type="info"
                      showIcon
                    />
                  </Col>
                  
                  {Object.entries(kpiStats.anomaly_stats || {}).map(([kpi, stats]) => (
                    <Col span={8} key={kpi}>
                      <Card size="small" title={kpiConfig[kpi]?.name || kpi}>
                        <Statistic
                          title="Anomaly Count"
                          value={stats.count}
                          valueStyle={{ color: '#cf1322' }}
                        />
                        <div style={{ marginTop: 8 }}>
                          <div>Avg Score: <Tag>{stats.avg_score}</Tag></div>
                          <div>Affected Cells: <Tag>{stats.unique_cells}</Tag></div>
                        </div>
                      </Card>
                    </Col>
                  ))}
                </Row>
              </Card>
            )
          }
        ]}
      />

      {anomalies.length > 0 && (
        <Alert
          message={`${anomalies.length} active anomalies detected`}
          description={`Filtered by: ${filters.kpiType || 'All KPIs'} | ${filters.cellId || 'All Cells'} | ${filters.timeRange}`}
          type="warning"
          showIcon
          style={{ marginTop: '24px' }}
        />
      )}
    </div>
  )
}

export default Dashboard
