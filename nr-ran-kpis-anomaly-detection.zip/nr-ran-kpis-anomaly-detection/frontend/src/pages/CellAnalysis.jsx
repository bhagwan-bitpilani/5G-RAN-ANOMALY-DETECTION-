import React, { useState, useEffect } from 'react'
import { Card, Row, Col, Select, Table, Tag, Statistic, Spin, Alert } from 'antd'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { WifiOutlined, ExclamationCircleOutlined } from '@ant-design/icons'
import axios from 'axios'

const { Option } = Select

const CellAnalysis = () => {
  const [selectedCell, setSelectedCell] = useState(null)
  const [cellAnomalies, setCellAnomalies] = useState([])
  const [kpiData, setKpiData] = useState([])
  const [loading, setLoading] = useState(false)
  const [kpiConfig, setKpiConfig] = useState({})

  useEffect(() => {
    fetchKpiConfig()
  }, [])

  useEffect(() => {
    if (selectedCell) {
      fetchCellData()
    }
  }, [selectedCell])

  const fetchKpiConfig = async () => {
    try {
      const response = await axios.get('/api/kpi/config')
      setKpiConfig(response.data)
    } catch (error) {
      console.error('Error fetching KPI config:', error)
    }
  }

  const fetchCellData = async () => {
    setLoading(true)
    try {
      // Fetch cell anomalies
      const anomaliesResponse = await axios.get(`/api/cells/${selectedCell}/anomalies`)
      setCellAnomalies(anomaliesResponse.data.anomalies || [])

      // Fetch dashboard data for this cell to get KPI trends
      const dashboardResponse = await axios.get('/api/dashboard/combined', {
        params: { cell_id: selectedCell }
      })
      setKpiData(dashboardResponse.data.kpis || [])
    } catch (error) {
      console.error('Error fetching cell data:', error)
      // Use sample data for demo
      setCellAnomalies(generateSampleCellAnomalies())
      setKpiData(generateSampleKpiData())
    } finally {
      setLoading(false)
    }
  }

  const generateSampleCellAnomalies = () => {
    return [
      {
        id: 1,
        kpi_type: 'downlink_ue_throughput',
        anomaly_score: 0.89,
        detected_at: new Date().toISOString(),
        kpi_value: 25.5,
        threshold_low: 40,
        threshold_high: 180
      },
      {
        id: 2,
        kpi_type: 'downlink_prb_utilization',
        anomaly_score: 0.76,
        detected_at: new Date(Date.now() - 300000).toISOString(),
        kpi_value: 92.3,
        threshold_low: 0,
        threshold_high: 80
      }
    ]
  }

  const generateSampleKpiData = () => {
    const data = []
    for (let i = 0; i < 20; i++) {
      data.push({
        timestamp: new Date(Date.now() - (19 - i) * 60000).toISOString(),
        downlink_ue_throughput: Math.random() * 150 + 30,
        downlink_prb_utilization: Math.random() * 100,
        latency: Math.random() * 30 + 5,
        downlink_payload_gb: Math.random() * 60 + 10
      })
    }
    return data
  }

  const prepareKpiChartData = (kpiType) => {
    return kpiData.map(kpi => ({
      timestamp: kpi.timestamp,
      value: kpi[kpiType],
      threshold_low: kpiConfig[kpiType]?.threshold_low,
      threshold_high: kpiConfig[kpiType]?.threshold_high
    }))
  }

  const anomalyColumns = [
    {
      title: 'KPI Type',
      dataIndex: 'kpi_type',
      key: 'kpi_type',
      render: (kpiType) => (
        <Tag color="blue">
          {kpiConfig[kpiType]?.name || kpiType}
        </Tag>
      ),
    },
    {
      title: 'Value',
      dataIndex: 'kpi_value',
      key: 'kpi_value',
      render: (value, record) => (
        <span>
          {value} {kpiConfig[record.kpi_type]?.unit || ''}
        </span>
      ),
    },
    {
      title: 'Thresholds',
      key: 'thresholds',
      render: (_, record) => (
        <span>
          {record.threshold_low} - {record.threshold_high} {kpiConfig[record.kpi_type]?.unit || ''}
        </span>
      ),
    },
    {
      title: 'Score',
      dataIndex: 'anomaly_score',
      key: 'score',
      render: score => (
        <Tag color={score > 0.8 ? 'red' : score > 0.6 ? 'orange' : 'yellow'}>
          {score.toFixed(3)}
        </Tag>
      ),
    },
    {
      title: 'Detected At',
      dataIndex: 'detected_at',
      key: 'detected_at',
      render: date => new Date(date).toLocaleString()
    },
  ]

  const kpiTypes = Object.keys(kpiConfig)

  return (
    <div style={{ padding: '24px' }}>
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: '12px', marginBottom: 4 }}>Select Cell</div>
            <Select
              placeholder="Select a cell for analysis"
              style={{ width: 200 }}
              value={selectedCell}
              onChange={setSelectedCell}
            >
              <Option value="NR2600_001">NR2600_001</Option>
              <Option value="NR2600_002">NR2600_002</Option>
              <Option value="NR700_015">NR700_015</Option>
              <Option value="NR700_033">NR700_033</Option>
            </Select>
          </div>
          
          {selectedCell && (
            <div>
              <Statistic
                title="Selected Cell"
                value={selectedCell}
                prefix={<WifiOutlined />}
              />
            </div>
          )}
        </div>
      </Card>

      {!selectedCell ? (
        <Alert
          message="Select a cell to view detailed analysis"
          type="info"
          showIcon
        />
      ) : loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '200px' }}>
          <Spin size="large" />
        </div>
      ) : (
        <Row gutter={[16, 16]}>
          {/* Statistics */}
          <Col span={24}>
            <Row gutter={[16, 16]}>
              <Col span={6}>
                <Card>
                  <Statistic
                    title="Total Anomalies"
                    value={cellAnomalies.length}
                    prefix={<ExclamationCircleOutlined />}
                    valueStyle={{ color: cellAnomalies.length > 0 ? '#cf1322' : '#3f8600' }}
                  />
                </Card>
              </Col>
              <Col span={6}>
                <Card>
                  <Statistic
                    title="Affected KPIs"
                    value={new Set(cellAnomalies.map(a => a.kpi_type)).size}
                    suffix={`/ ${kpiTypes.length}`}
                  />
                </Card>
              </Col>
              <Col span={6}>
                <Card>
                  <Statistic
                    title="Avg Anomaly Score"
                    value={cellAnomalies.length > 0 
                      ? (cellAnomalies.reduce((sum, a) => sum + a.anomaly_score, 0) / cellAnomalies.length).toFixed(3)
                      : 0
                    }
                  />
                </Card>
              </Col>
              <Col span={6}>
                <Card>
                  <Statistic
                    title="Data Points"
                    value={kpiData.length}
                  />
                </Card>
              </Col>
            </Row>
          </Col>

          {/* KPI Charts */}
          <Col span={12}>
            <Card title="KPI Trends" bordered={false}>
              <Select
                placeholder="Select KPI to plot"
                style={{ width: '100%', marginBottom: 16 }}
                defaultValue={kpiTypes[0]}
              >
                {kpiTypes.map(kpi => (
                  <Option key={kpi} value={kpi}>
                    {kpiConfig[kpi]?.name || kpi}
                  </Option>
                ))}
              </Select>
              
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={prepareKpiChartData(kpiTypes[0])}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="timestamp" 
                    tickFormatter={(value) => new Date(value).toLocaleTimeString()}
                  />
                  <YAxis />
                  <Tooltip 
                    labelFormatter={(value) => new Date(value).toLocaleString()}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#8884d8" 
                    name="KPI Value"
                    strokeWidth={2}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="threshold_low" 
                    stroke="#ff4d4f" 
                    strokeDasharray="5 5"
                    name="Lower Threshold"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="threshold_high" 
                    stroke="#ff4d4f" 
                    strokeDasharray="5 5"
                    name="Upper Threshold"
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </Col>

          {/* Anomalies Table */}
          <Col span={12}>
            <Card title="Cell Anomalies" bordered={false}>
              <Table
                dataSource={cellAnomalies}
                columns={anomalyColumns}
                pagination={{ pageSize: 5 }}
                size="small"
                rowKey="id"
                scroll={{ y: 300 }}
              />
            </Card>
          </Col>
        </Row>
      )}
    </div>
  )
}

export default CellAnalysis
