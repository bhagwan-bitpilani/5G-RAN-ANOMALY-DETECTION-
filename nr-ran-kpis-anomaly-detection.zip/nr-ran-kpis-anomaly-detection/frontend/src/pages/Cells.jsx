import React, { useState, useEffect } from 'react'
import { Table, Tag, Card, Spin, Row, Col } from 'antd'
import axios from 'axios'

const Cells = () => {
  const [cells, setCells] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchCells()
  }, [])

  const fetchCells = async () => {
    try {
      const response = await axios.get('/api/cells')
      setCells(response.data)
    } catch (error) {
      console.error('Error fetching cells:', error)
      // Sample data for demo
      const sampleCells = []
      for (let i = 1; i <= 50; i++) {
        sampleCells.push({
          cell_id: `NR2600_${i.toString().padStart(3, '0')}`,
          band: 'NR2600',
          location: `Sector_${((i - 1) % 3) + 1}`,
          sector: ((i - 1) % 3) + 1,
          status: 'active'
        })
      }
      for (let i = 1; i <= 50; i++) {
        sampleCells.push({
          cell_id: `NR700_${i.toString().padStart(3, '0')}`,
          band: 'NR700',
          location: `Sector_${((i - 1) % 3) + 1}`,
          sector: ((i - 1) % 3) + 1,
          status: 'active'
        })
      }
      setCells(sampleCells)
    } finally {
      setLoading(false)
    }
  }

  const columns = [
    {
      title: 'Cell ID',
      dataIndex: 'cell_id',
      key: 'cell_id',
    },
    {
      title: 'Band',
      dataIndex: 'band',
      key: 'band',
      render: (band) => (
        <Tag color={band === 'NR2600' ? 'blue' : 'green'}>{band}</Tag>
      ),
    },
    {
      title: 'Location',
      dataIndex: 'location',
      key: 'location',
    },
    {
      title: 'Sector',
      dataIndex: 'sector',
      key: 'sector',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={status === 'active' ? 'green' : 'red'}>{status}</Tag>
      ),
    },
  ]

  const bandStats = {
    NR2600: cells.filter(cell => cell.band === 'NR2600').length,
    NR700: cells.filter(cell => cell.band === 'NR700').length
  }

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
        <Spin size="large" />
      </div>
    )
  }

  return (
    <div style={{ padding: '24px' }}>
      <Row gutter={[16, 16]} style={{ marginBottom: '24px' }}>
        <Col span={12}>
          <Card>
            <Statistic
              title="NR2600 Cells"
              value={bandStats.NR2600}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col span={12}>
          <Card>
            <Statistic
              title="NR700 Cells"
              value={bandStats.NR700}
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
      </Row>

      <Card title="NR Cells" bordered={false} className="dashboard-card">
        <Table 
          dataSource={cells} 
          columns={columns} 
          rowKey="cell_id"
          pagination={{ pageSize: 10 }}
          scroll={{ x: 800 }}
        />
      </Card>
    </div>
  )
}

export default Cells
