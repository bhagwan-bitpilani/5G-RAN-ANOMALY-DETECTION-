CREATE TABLE IF NOT EXISTS nr_cells (
    id SERIAL PRIMARY KEY,
    cell_id VARCHAR(50) UNIQUE NOT NULL,
    band VARCHAR(20) NOT NULL,
    location VARCHAR(100),
    sector INTEGER,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS kpi_data (
    id SERIAL PRIMARY KEY,
    cell_id VARCHAR(50) NOT NULL,
    kpi_type VARCHAR(50),
    kpi_value FLOAT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    band VARCHAR(20),
    nr_ue_throughput FLOAT,
    data_session_success_rate FLOAT,
    endc_setup_success_rate FLOAT,
    pscell_change_success_rate FLOAT,
    latency FLOAT,
    nr_connected_users INTEGER,
    downlink_latency FLOAT
);

CREATE TABLE IF NOT EXISTS anomaly_detections (
    id SERIAL PRIMARY KEY,
    kpi_id INTEGER,
    anomaly_score FLOAT,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    kpi_type VARCHAR(50),
    is_resolved BOOLEAN DEFAULT FALSE,
    resolution_notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_kpi_data_cell_id ON kpi_data(cell_id);
CREATE INDEX IF NOT EXISTS idx_kpi_data_timestamp ON kpi_data(timestamp);
CREATE INDEX IF NOT EXISTS idx_anomalies_detected_at ON anomaly_detections(detected_at);
