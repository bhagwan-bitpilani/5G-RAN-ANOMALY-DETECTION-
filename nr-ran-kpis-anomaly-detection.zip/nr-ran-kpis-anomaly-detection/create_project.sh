#!/bin/bash

PROJECT_ROOT="5g-nr-anomaly-detection"

create_directories() {
    echo "Creating directory structure..."
    
    # Main directories
    mkdir -p $PROJECT_ROOT/{k8s,app,frontend,ml-scheduler,monitoring,database,scripts,charts,docs,tests,config,logs,data,.github,.docker,.vscode}
    
    # Backend structure
    mkdir -p $PROJECT_ROOT/app/{api/{endpoints,websockets},services,ml/{models,features,training},tests}
    
    # Frontend structure  
    mkdir -p $PROJECT_ROOT/frontend/{public,src/{components/{Dashboard,Charts,Tables,Forms,Layout,Common},pages,services,hooks,context,utils,styles}}
    
    # Monitoring structure
    mkdir -p $PROJECT_ROOT/monitoring/{prometheus,grafana/{dashboards,datasources},alerts/{email-templates}}
    
    # Database structure
    mkdir -p $PROJECT_ROOT/database/{migrations,seeds,scripts}
    
    # Scripts structure
    mkdir -p $PROJECT_ROOT/scripts/deploy
    
    # Charts structure
    mkdir -p $PROJECT_ROOT/charts/5g-anomaly-detection/{templates,charts/{postgresql,redis,prometheus}}
    
    # Docs structure
    mkdir -p $PROJECT_ROOT/docs/{architecture,api,user-guide,development}
    
    # Tests structure
    mkdir -p $PROJECT_ROOT/tests/{unit,integration,e2e,performance,fixtures}
    
    # Logs structure
    mkdir -p $PROJECT_ROOT/logs/{application,nginx,postgresql,prometheus}
    
    # Data structure
    mkdir -p $PROJECT_ROOT/data/{uploads/{excel,csv},models/{trained,archived},exports/{reports,backups},temp}
    
    # CI/CD structure
    mkdir -p $PROJECT_ROOT/.github/{workflows,ISSUE_TEMPLATE,PULL_REQUEST_TEMPLATE}
    mkdir -p $PROJECT_ROOT/.docker/{nginx,postgres,prometheus}
}

create_files() {
    echo "Creating essential files..."
    
    # Root level files
    touch $PROJECT_ROOT/{docker-compose.yml,docker-compose.prod.yml,Makefile,requirements.txt,requirements-dev.txt,pyproject.toml,.env.example,.gitignore,.dockerignore,README.md,LICENSE}
    
    # Backend Python files
    touch $PROJECT_ROOT/app/{__init__.py,main.py,models.py,schemas.py,database.py,ml_anomaly_detector.py,sla_scheduler.py,kpi_processor.py,security.py,dependencies.py,config.py,crud.py,utils.py,prometheus_metrics.py}
    
    # Backend API files
    touch $PROJECT_ROOT/app/api/__init__.py
    touch $PROJECT_ROOT/app/api/endpoints/{__init__.py,auth.py,kpi.py,cells.py,anomalies.py,upload.py,dashboard.py}
    touch $PROJECT_ROOT/app/api/websockets/{__init__.py,notifications.py}
    
    # Backend services
    touch $PROJECT_ROOT/app/services/{__init__.py,kpi_service.py,anomaly_service.py,notification_service.py,cell_service.py}
    
    # ML components
    touch $PROJECT_ROOT/app/ml/__init__.py
    touch $PROJECT_ROOT/app/ml/models/{__init__.py,isolation_forest.py,lstm_autoencoder.py,ensemble.py}
    touch $PROJECT_ROOT/app/ml/features/{__init__.py,engineering.py,selection.py}
    touch $PROJECT_ROOT/app/ml/training/{__init__.py,trainer.py,pipelines.py}
    
    # Backend tests
    touch $PROJECT_ROOT/app/tests/{__init__.py,test_api.py,test_models.py,test_ml.py,conftest.py}
    
    # Frontend files
    touch $PROJECT_ROOT/frontend/{package.json,package-lock.json,Dockerfile,nginx.conf}
    touch $PROJECT_ROOT/frontend/public/{index.html,favicon.ico,manifest.json}
    touch $PROJECT_ROOT/frontend/src/{App.js,App.css,index.js,routes.js}
    
    # ML Scheduler files
    touch $PROJECT_ROOT/ml-scheduler/{__init__.py,main.py,scheduler.py,metrics_collector.py,decision_engine.py,scaling_executor.py,config.py,requirements.txt,Dockerfile}
    
    # Monitoring configuration files
    touch $PROJECT_ROOT/monitoring/prometheus/{prometheus.yml,alert_rules.yml,recording_rules.yml}
    touch $PROJECT_ROOT/monitoring/grafana/dashboards/{kpi-overview.json,anomaly-detection.json,cell-level.json,system-metrics.json,sla-monitoring.json}
    touch $PROJECT_ROOT/monitoring/grafana/datasources/prometheus.yml
    touch $PROJECT_ROOT/monitoring/grafana/provisioning.yaml
    touch $PROJECT_ROOT/monitoring/alerts/slack-config.yml
    
    # Database scripts
    touch $PROJECT_ROOT/database/migrations/{001_initial_schema.sql,002_add_anomaly_tables.sql,003_add_resource_metrics.sql,004_add_indexes.sql}
    touch $PROJECT_ROOT/database/seeds/{nr_cells_seed.sql,kpi_reference_data.sql,test_data.sql}
    touch $PROJECT_ROOT/database/scripts/{init-db.sh,backup.sh,restore.sh}
    
    # Utility scripts
    touch $PROJECT_ROOT/scripts/{generate_dummy_data.py,excel_uploader.py,kpi_simulator.py,model_training.py,performance_test.py,security_scan.py}
    touch $PROJECT_ROOT/scripts/deploy/{build_images.sh,deploy_k8s.sh,health_check.sh}
    
    # Helm chart files
    touch $PROJECT_ROOT/charts/5g-anomaly-detection/{Chart.yaml,values.yaml}
    
    # Documentation files
    touch $PROJECT_ROOT/docs/architecture/{system-architecture.md,data-flow.md,deployment-guide.md}
    touch $PROJECT_ROOT/docs/api/{openapi.yaml,postman-collection.json,api-reference.md}
    touch $PROJECT_ROOT/docs/user-guide/{installation.md,configuration.md,troubleshooting.md}
    touch $PROJECT_ROOT/docs/development/{setup.md,testing.md,contributing.md}
    
    # Test files
    touch $PROJECT_ROOT/tests/unit/{test_models.py,test_services.py,test_ml_detector.py,test_scheduler.py}
    touch $PROJECT_ROOT/tests/integration/{test_api_integration.py,test_database.py,test_kpi_processing.py,test_anomaly_detection.py}
    touch $PROJECT_ROOT/tests/e2e/{test_dashboard.py,test_upload.py,test_alerts.py}
    touch $PROJECT_ROOT/tests/performance/{load_test.py,stress_test.py,kpi_simulation.py}
    touch $PROJECT_ROOT/tests/fixtures/{sample_data.json,test_cells.csv,mock_kpis.json}
    
    # Configuration files
    touch $PROJECT_ROOT/config/{development.yaml,production.yaml,staging.yaml,security.yaml,logging.yaml}
    
    # CI/CD files
    touch $PROJECT_ROOT/.github/workflows/{ci.yml,cd.yml,security-scan.yml,performance-test.yml}
    
    # Docker configuration files
    touch $PROJECT_ROOT/.docker/nginx/nginx.conf
    touch $PROJECT_ROOT/.docker/postgres/init.sql
    touch $PROJECT_ROOT/.docker/prometheus/prometheus.yml
    
    # IDE configuration
    touch $PROJECT_ROOT/.vscode/{settings.json,extensions.json,launch.json}
}

set_permissions() {
    echo "Setting execution permissions..."
    chmod +x $PROJECT_ROOT/scripts/*.py
    chmod +x $PROJECT_ROOT/scripts/deploy/*.sh
    chmod +x $PROJECT_ROOT/database/scripts/*.sh
}

main() {
    create_directories
    create_files
    set_permissions
    echo "Project structure created successfully in: $PROJECT_ROOT"
    echo "Total directories created: $(find $PROJECT_ROOT -type d | wc -l)"
    echo "Total files created: $(find $PROJECT_ROOT -type f | wc -l)"
}

main
