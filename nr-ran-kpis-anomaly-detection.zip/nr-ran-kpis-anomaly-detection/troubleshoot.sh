#!/bin/bash

echo "🔧 Troubleshooting 5G NR Application..."

# Function to check service
check_service() {
    local service=$1
    local port=$2
    local url=$3
    
    echo "Checking $service..."
    
    # Check if container is running
    if docker-compose ps | grep -q "$service.*Up"; then
        echo "✅ $service container is running"
    else
        echo "❌ $service container is NOT running"
        return 1
    fi
    
    # Check if service is responding
    if curl -s --retry 3 --retry-delay 2 "$url" > /dev/null; then
        echo "✅ $service is responding on port $port"
        return 0
    else
        echo "❌ $service is NOT responding on port $port"
        return 1
    fi
}

# Stop existing services
echo "🛑 Stopping existing services..."
docker-compose down

# Build services
echo "🔨 Building services..."
docker-compose build --no-cache

# Start services
echo "🚀 Starting services..."
docker-compose up -d

# Wait for services to start
echo "⏳ Waiting for services to initialize..."
sleep 30

# Check each service
echo ""
echo "📊 Service Status Check:"
echo "========================"

check_service "backend" "8000" "http://localhost:8000/health"
backend_ok=$?

check_service "frontend" "3000" "http://localhost:3000"
frontend_ok=$?

check_service "postgresql" "5432" "http://localhost:5432"  # This will fail but we check container
postgres_ok=$(docker-compose ps | grep -q "postgresql.*Up" && echo 0 || echo 1)

check_service "redis" "6379" "http://localhost:6379"  # This will fail but we check container
redis_ok=$(docker-compose ps | grep -q "redis.*Up" && echo 0 || echo 1)

# Show logs if services are failing
echo ""
echo "📋 Summary:"
echo "==========="

if [ $backend_ok -eq 0 ]; then
    echo "✅ Backend: RUNNING - http://localhost:8000"
    echo "   API Docs: http://localhost:8000/docs"
else
    echo "❌ Backend: FAILED"
    echo "🔍 Backend logs:"
    docker-compose logs backend --tail=20
fi

if [ $frontend_ok -eq 0 ]; then
    echo "✅ Frontend: RUNNING - http://localhost:3000"
else
    echo "❌ Frontend: FAILED"
    echo "🔍 Frontend logs:"
    docker-compose logs frontend --tail=20
fi

if [ $postgres_ok -eq 0 ]; then
    echo "✅ PostgreSQL: RUNNING - port 5432"
else
    echo "❌ PostgreSQL: FAILED"
fi

if [ $redis_ok -eq 0 ]; then
    echo "✅ Redis: RUNNING - port 6379"
else
    echo "❌ Redis: FAILED"
fi

echo ""
echo "🎯 Next steps:"
if [ $backend_ok -eq 0 ] && [ $frontend_ok -eq 0 ]; then
    echo "✅ Application is running successfully!"
    echo "   Frontend: http://localhost:3000"
    echo "   Backend API: http://localhost:8000"
    echo "   API Documentation: http://localhost:8000/docs"
else
    echo "❌ Some services failed to start."
    echo "   Check detailed logs with: docker-compose logs"
    echo "   Restart services with: docker-compose restart"
fi

echo ""
echo "🛠️  Useful commands:"
echo "   docker-compose logs -f [service]  # View logs for a service"
echo "   docker-compose restart [service]  # Restart a specific service"
echo "   docker-compose down              # Stop all services"
echo "   docker-compose up -d             # Start all services"
