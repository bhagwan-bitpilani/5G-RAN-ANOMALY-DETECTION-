#!/bin/bash

echo "🔍 Testing Frontend-Backend Connection..."

echo "1. Testing Backend Directly..."
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Backend is running on port 8000"
else
    echo "❌ Backend is NOT running on port 8000"
    echo "   Check with: docker-compose logs backend"
fi

echo ""
echo "2. Testing Frontend..."
if curl -s http://localhost:3000 > /dev/null; then
    echo "✅ Frontend is running on port 3000"
else
    echo "❌ Frontend is NOT running on port 3000"
    echo "   Check with: docker-compose logs frontend"
fi

echo ""
echo "3. Testing API through Frontend Proxy..."
if curl -s http://localhost:3000/api/health > /dev/null; then
    echo "✅ Frontend can proxy to backend"
else
    echo "❌ Frontend cannot proxy to backend"
    echo "   This is the likely cause of login issues"
fi

echo ""
echo "4. Testing Login Endpoint..."
response=$(curl -s -w "%{http_code}" -X POST http://localhost:8000/api/auth/login -d "username=admin&password=admin")
http_code=${response: -3}

if [ "$http_code" = "200" ]; then
    echo "✅ Login endpoint is working"
else
    echo "❌ Login endpoint returned HTTP $http_code"
fi

echo ""
echo "📋 Summary:"
echo "==========="
echo "If backend tests pass but proxy test fails, the nginx configuration needs fixing."
echo "If all tests pass, the issue might be in the frontend code."
echo ""
echo "🚀 Quick Fix Commands:"
echo "   docker-compose restart frontend"
echo "   docker-compose logs frontend --tail=20"
echo "   docker-compose exec frontend nginx -t"
